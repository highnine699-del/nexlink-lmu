# Copyright (c) 2026 Odetayo Josiah Inioluwa. All rights reserved.
# Licensed under the terms in LICENSE.md — see repository
#
# NexLink-WPF.ps1
# WPF-based UI overhaul with all backend logic preserved from NexLink-GUI.ps1
#
# HOW TO RUN (important - do NOT double-click the file):
#   1. Right-click Start -> "Windows PowerShell (Admin)" or "Terminal (Admin)"
#   2. cd to the folder where this file is saved, e.g.: cd "Downloads\wifi setup"
#   3. If blocked, run once:  Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   4. Then run:  .\NexLink-WPF.ps1

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
# Invoke-WebRequest reports download progress via Write-Progress. In a normal
# console this is invisible, but in a ps2exe -noConsole build, that progress
# event renders as an actual modal dialog that blocks the entire WinForms
# message loop - freezing the whole app. Suppress it entirely.
$ProgressPreference = 'SilentlyContinue'

# ---------- Graceful exit signal ----------
# release.ps1 runs unelevated, but NexLink.exe runs elevated (-requireAdmin),
# so Stop-Process from release.ps1 fails with Access Denied and window
# messages are blocked by UIPI across the elevation boundary. File I/O isn't
# blocked though, so release.ps1 drops this file to ask for a graceful exit,
# and the timer loop below polls for it every tick.
$script:ExitSignalFile = Join-Path $env:TEMP "NexLink.exitsignal"
Remove-Item $script:ExitSignalFile -ErrorAction SilentlyContinue

# ---------- Single-instance guard ----------
# Prevents two copies (e.g. a manual .ps1 run plus the .exe) from running at
# once and hammering the login endpoint independently of each other.
$script:InstanceMutex = New-Object System.Threading.Mutex($false, "Global\NexLink-SingleInstance")
try {
    $acquired = $script:InstanceMutex.WaitOne(0)
}
catch [System.Threading.AbandonedMutexException] {
    # Previous instance crashed/exited without releasing - we now own it, proceed.
    $acquired = $true
}
if (-not $acquired) {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("NexLink is already running (check your system tray).", "NexLink") | Out-Null
    exit
}

# ---------- Backend Functions (UNCHANGED from NexLink-GUI.ps1) ----------
function Get-WifiAdapter {
    try {
        return Get-NetAdapter | Where-Object { $_.Status -ne 'Disabled' -and $_.InterfaceDescription -match 'Wi-Fi|Wireless' } | Select-Object -First 1
    }
    catch {
        return $null
    }
}

function Get-CurrentSSID {
    try {
        $result = netsh wlan show interfaces 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        $line = $result | Select-String '^\s*SSID\s*:\s*(.+)$'
        if ($line) { return ($line.Matches[0].Groups[1].Value).Trim() }
    }
    catch {}
    return $null
}

function Get-VisibleWifiNetworks {
    $networks = @()
    try {
        $output = netsh wlan show networks mode=BSSID 2>$null
        if ($LASTEXITCODE -ne 0) { return $networks }

        $currentNetwork = $null
        foreach ($line in $output) {
            if ($line -match '^\s*SSID\s+\d+\s*:\s*(.+?)\s*$') {
                if ($currentNetwork) { $networks += [PSCustomObject]$currentNetwork }
                $currentNetwork = [ordered]@{ SSID = $matches[1].Trim(); Signal = $null }
            }
            elseif ($currentNetwork -and $line -match '^\s*Signal\s*:\s*(\d+)\s*%') {
                $currentNetwork.Signal = [int]$matches[1]
            }
        }

        if ($currentNetwork) { $networks += [PSCustomObject]$currentNetwork }
    }
    catch {}

    return $networks
}

# ---------- Settings ----------
$NexLinkVersion = "1.3.9"
$UpdateManifestUrl = "https://raw.githubusercontent.com/highnine699-del/nexlink-updates/main/latest.json"
$UpdateCheckEnabled = $true
$PingTargets = @("8.8.8.8", "1.1.1.1")
$TestPageUrls = @(
    @{ Url = "http://www.msftconnecttest.com/connecttest.txt"; ExpectedText = "Microsoft Connect Test" },
    @{ Url = "http://detectportal.firefox.com/success.txt"; ExpectedText = "success" }
)
$LoginUrl = "https://internet.lmu.edu.ng/login"
$LogoutUrl = "https://internet.lmu.edu.ng/logout"
$CheckIntervalMs = 5000
$WifiFailsBeforeFix = 3
$ReconnectCooldownSec = 10
$PortalLoginRetryCooldownSec = 30
$MaxLogLines = 5000
$TrustedNetworks = @(
    'Abraham Metro Wifi |2|',
    'Abraham Reception',
    'Abraham-Metro Wifi',
    'CSC_WIFI',
    'CSIS|Eng Workshop|4',
    'CSIS|Mech Lab_50',
    'Daniel-Metro Wifi',
    'Jacob Metro Wifi',
    'Jacob Reception',
    'LMU-Metro Wifi',
    'Metro wifi cafeteria',
    'Sarah Metro Wifi',
    'Wing C Coutyard Wifi',
    'Wing C Coutyard Wifi| 5GHz|',
    'csis|eng workshop|1|31'
)
$ScriptDir = Split-Path -Path ([System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName) -Parent
$CredFile = Join-Path $ScriptDir "lmu_portal.cred"
$LogFile = Join-Path $ScriptDir "lmu_autoconnect.log"

$script:wifiFailCount = 0
$script:portalFailCount = 0
$script:portalUnknownCount = 0
$script:LastKnownSSID = $null
$script:secondsToNextCheck = $CheckIntervalMs / 1000
$script:PortalRetryAfter = [DateTime]::MinValue
$script:PortalCooldownShown = $false
$script:LastReconnectAt = [DateTime]::MinValue
$script:PortalSession = $null
$script:LastLogTrimAt = Get-Date
$script:LastLoggedStatus = ""
$script:LastHealthyLogAt = [DateTime]::MinValue
$script:LastUpdateCheckAt = [DateTime]::MinValue
$script:PendingUpdateManifest = $null

# ---------- Credential handling ----------
function Save-PortalCredential {
    $inputForm = New-Object System.Windows.Forms.Form
    $inputForm.Text = "LMU Portal Login"
    $inputForm.Size = New-Object System.Drawing.Size(340, 220)
    $inputForm.StartPosition = "CenterScreen"
    $inputForm.FormBorderStyle = "FixedDialog"
    $inputForm.MaximizeBox = $false
    $inputForm.TopMost = $false

    $lblUser = New-Object System.Windows.Forms.Label -Property @{ Text = "Portal Username:"; Location = "20,20"; Size = "280,20" }
    $txtUser = New-Object System.Windows.Forms.TextBox -Property @{ Location = "20,45"; Size = "280,20" }
    $lblPass = New-Object System.Windows.Forms.Label -Property @{ Text = "Portal Password:"; Location = "20,80"; Size = "280,20" }
    $txtPass = New-Object System.Windows.Forms.TextBox -Property @{ Location = "20,105"; Size = "280,20"; UseSystemPasswordChar = $true }
    $btnOk = New-Object System.Windows.Forms.Button -Property @{ Text = "Save"; Location = "110,145"; Size = "100,30"; DialogResult = "OK" }

    $inputForm.Controls.AddRange(@($lblUser, $txtUser, $lblPass, $txtPass, $btnOk))
    $inputForm.AcceptButton = $btnOk
    $inputForm.Add_Shown({ $inputForm.Activate(); $txtUser.Focus() })
    $result = $inputForm.ShowDialog()

    if ($result -eq "OK" -and $txtUser.Text -and $txtPass.Text) {
        $secure = ConvertTo-SecureString $txtPass.Text -AsPlainText -Force
        $encryptedPass = ConvertFrom-SecureString $secure
        try {
            @{ Username = $txtUser.Text; Password = $encryptedPass } | ConvertTo-Json | Set-Content -Path $CredFile -Encoding UTF8
            Add-Log "Credentials saved for user '$($txtUser.Text)' (password stored encrypted, never logged)."
            return $true
        }
        catch {
            Add-Log "FAILED to save credentials: $($_.Exception.Message)"
            [System.Windows.Forms.MessageBox]::Show("Unable to save credentials: $($_.Exception.Message)", "NexLink") | Out-Null
            return $false
        }
    }
    Add-Log "Credential entry cancelled or incomplete."
    return $false
}

function Get-PortalCredential {
    if (-not (Test-Path $CredFile)) {
        Add-Log "No credential file found at '$CredFile' - prompting for portal login."
        if (-not (Save-PortalCredential)) {
            [System.Windows.Forms.MessageBox]::Show("No credentials entered. Exiting.", "NexLink") | Out-Null
            exit
        }
    }

    try {
        $data = Get-Content $CredFile -Raw | ConvertFrom-Json
    }
    catch {
        Add-Log "Credential file is unreadable or corrupt: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("Credential file is unreadable or corrupt. Delete $CredFile and run again.", "NexLink") | Out-Null
        exit
    }

    if (-not $data.Username -or -not $data.Password) {
        Add-Log "Credential file is missing username or password field."
        [System.Windows.Forms.MessageBox]::Show("Credential file is missing required values.", "NexLink") | Out-Null
        exit
    }

    try {
        $securePass = ConvertTo-SecureString $data.Password
    }
    catch {
        Add-Log "Saved password could not be decrypted (DPAPI mismatch - different user/machine?): $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("Saved password could not be decrypted. Delete $CredFile and create it again.", "NexLink") | Out-Null
        exit
    }

    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePass)
    try {
        $plainPass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
    }
    finally {
        [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
    return @{ Username = [string]$data.Username; Password = $plainPass }
}

# ---------- Wifi helpers ----------
function Update-KnownSSID {
    $current = Get-CurrentSSID
    if ($current) { $script:LastKnownSSID = $current }
    return $current
}

function Clear-DnsCache {
    try {
        ipconfig /flushdns | Out-Null
    }
    catch {}
}

function Test-ForUpdate {
    # Fully defensive by design: any failure here (network, bad JSON,
    # malformed version string) must be swallowed silently and never
    # affect the rest of the app. This function only ever returns a
    # manifest object when a genuinely newer version is confirmed.
    if (-not $UpdateCheckEnabled) { return $null }
    try {
        $resp = Invoke-WebRequest -Uri $UpdateManifestUrl -UseBasicParsing -TimeoutSec 8 -ErrorAction Stop
        $rawContent = $resp.Content.TrimStart([char]0xFEFF, [char]0x200B).Trim()
        $manifest = $rawContent | ConvertFrom-Json -ErrorAction Stop
        if (-not $manifest.version -or -not $manifest.installer_url -or -not $manifest.sha256) {
            Add-Log "Update check: manifest is missing required fields, ignoring."
            return $null
        }
        $remoteVersion = [version]$manifest.version
        $currentVersion = [version]$NexLinkVersion
        if ($remoteVersion -gt $currentVersion) {
            Add-Log "Update check: v$($manifest.version) is available (current: v$NexLinkVersion)."
            return $manifest
        }
        else {
            Add-Log "Update check: up to date (v$NexLinkVersion)."
            return $null
        }
    }
    catch {
        Add-Log "Update check failed (non-fatal, app continues normally): $($_.Exception.Message)"
        return $null
    }
}

function Start-NexLinkUpdate($manifest) {
    # CRITICAL ORDERING: download + hash verification happen BEFORE anything
    # about the currently running app is touched. If either step fails, we
    # return early and the running app is completely unaffected - it never
    # even knows an update attempt was made, beyond the log entry.
    $tempInstaller = Join-Path $env:TEMP "NexLink-Update-$($manifest.version).exe"
    try {
        Add-Log "Downloading update v$($manifest.version)..."
        Invoke-WebRequest -Uri $manifest.installer_url -OutFile $tempInstaller -UseBasicParsing -TimeoutSec 60 -ErrorAction Stop
    }
    catch {
        Add-Log "Update download FAILED (app unaffected, still running normally): $($_.Exception.Message)"
        [System.Windows.MessageBox]::Show("Couldn't download the update. Your current version is unaffected and still running.`n`n$($_.Exception.Message)", "NexLink Update") | Out-Null
        Remove-Item $tempInstaller -ErrorAction SilentlyContinue
        return
    }

    try {
        $actualHash = (Get-FileHash -Path $tempInstaller -Algorithm SHA256 -ErrorAction Stop).Hash
        if ($actualHash -ne $manifest.sha256.ToUpper()) {
            Add-Log "Update verification FAILED - hash mismatch. Aborting update, current app unaffected. Expected=$($manifest.sha256) Actual=$actualHash"
            [System.Windows.MessageBox]::Show("The downloaded update failed verification and will NOT be installed. Your current version is unaffected and still running.", "NexLink Update - Verification Failed") | Out-Null
            Remove-Item $tempInstaller -ErrorAction SilentlyContinue
            return
        }
        Add-Log "Update verified (SHA256 match). Proceeding with install."
    }
    catch {
        Add-Log "Update verification could not be completed (app unaffected, still running normally): $($_.Exception.Message)"
        Remove-Item $tempInstaller -ErrorAction SilentlyContinue
        return
    }

    # Only past this point do we touch the running app's state at all.
    $exePath = Join-Path $ScriptDir "NexLink.exe"
    try {
        Add-Log "Shutting down for update to v$($manifest.version)..."
        $timer.Stop()
        $trayIcon.Visible = $false
        try { $script:InstanceMutex.ReleaseMutex() } catch {}

        Start-Process -FilePath $tempInstaller -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART" -Wait

        if (Test-Path $exePath) {
            Start-Process -FilePath $exePath
        }
        Remove-Item $tempInstaller -ErrorAction SilentlyContinue
        [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
    }
    catch {
        Add-Log "Update install step failed: $($_.Exception.Message)"
        [System.Windows.MessageBox]::Show("The update installer failed to run. Please download and run it manually from GitHub.`n`n$($_.Exception.Message)", "NexLink Update") | Out-Null
    }
}

function Get-CurrentWifiState {
    try {
        $result = netsh wlan show interfaces 2>$null
        if ($LASTEXITCODE -ne 0) { return [PSCustomObject]@{ SSID = $null; Signal = 0 } }

        $ssid = $null
        $signal = 0
        $ssidLine = $result | Select-String '^\s*SSID\s*:\s*(.+)$'
        if ($ssidLine) { $ssid = ($ssidLine.Matches[0].Groups[1].Value).Trim() }

        $signalLine = $result | Select-String '^\s*Signal\s*:\s*(\d+)\s*%'
        if ($signalLine) { $signal = [int]$signalLine.Matches[0].Groups[1].Value }

        return [PSCustomObject]@{ SSID = $ssid; Signal = $signal }
    }
    catch {
        return [PSCustomObject]@{ SSID = $null; Signal = 0 }
    }
}

function Test-TrustedNetwork {
    param([string]$Ssid)
    if (-not $Ssid) { return $false }
    $normalized = $Ssid.Trim().ToLowerInvariant()
    foreach ($trusted in $TrustedNetworks) {
        if ($normalized -eq $trusted.Trim().ToLowerInvariant()) { return $true }
    }
    return $false
}

function Get-BestFreeNetwork {
    param([psobject]$CurrentWifiState = $null)

    if (-not $CurrentWifiState) { $CurrentWifiState = Get-CurrentWifiState }
    $visibleNetworks = Get-VisibleWifiNetworks | Where-Object { Test-TrustedNetwork -Ssid $_.SSID }
    $visibleNetworks = @($visibleNetworks)
    if (-not $visibleNetworks -or $visibleNetworks.Count -eq 0) { return $null }

    $currentSsid = if ($CurrentWifiState) { $CurrentWifiState.SSID } else { $null }
    $currentSignal = if ($CurrentWifiState) { $CurrentWifiState.Signal } else { 0 }

    $scored = foreach ($network in $visibleNetworks) {
        $name = [string]$network.SSID
        $signal = if ($null -ne $network.Signal) { [int]$network.Signal } else { 0 }
        $score = $signal
        if ($currentSsid -and $name -eq $currentSsid) { $score += 5 }
        if ($currentSsid -and $signal -ge ($currentSignal + 5)) { $score += 10 }
        [PSCustomObject]@{ SSID = $name; Signal = $signal; Score = $score }
    }

    $best = $scored | Sort-Object Score -Descending | Select-Object -First 1
    if ($best) { return $best.SSID }
    return $null
}

function Get-AllTrustedNetworksByScore {
    param([psobject]$CurrentWifiState = $null)

    if (-not $CurrentWifiState) { $CurrentWifiState = Get-CurrentWifiState }
    $visibleNetworks = Get-VisibleWifiNetworks | Where-Object { Test-TrustedNetwork -Ssid $_.SSID }
    $visibleNetworks = @($visibleNetworks)
    if (-not $visibleNetworks -or $visibleNetworks.Count -eq 0) { return @() }

    $currentSsid = if ($CurrentWifiState) { $CurrentWifiState.SSID } else { $null }
    $currentSignal = if ($CurrentWifiState) { $CurrentWifiState.Signal } else { 0 }

    $scored = foreach ($network in $visibleNetworks) {
        $name = [string]$network.SSID
        $signal = if ($null -ne $network.Signal) { [int]$network.Signal } else { 0 }
        $score = $signal
        if ($currentSsid -and $name -eq $currentSsid) { $score += 5 }
        if ($currentSsid -and $signal -ge ($currentSignal + 5)) { $score += 10 }
        [PSCustomObject]@{ SSID = $name; Signal = $signal; Score = $score }
    }

    return $scored | Sort-Object Score -Descending
}

function Connect-ToWifiNetwork {
    param([string]$Ssid)
    if (-not $Ssid) { return $false }
    netsh wlan connect name="$Ssid" 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { return $true }
    netsh wlan connect ssid="$Ssid" name="$Ssid" 2>$null | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Test-WifiSwitchNeeded {
    param(
        [string]$TargetSsid,
        [psobject]$CurrentWifiState
    )
    if (-not $TargetSsid) { return $false }
    if (-not (Test-TrustedNetwork -Ssid $TargetSsid)) { return $false }
    if (-not $CurrentWifiState -or -not $CurrentWifiState.SSID) { return $true }
    if ($TargetSsid -eq $CurrentWifiState.SSID) { return $false }
    if ($script:LastReconnectAt -and ((Get-Date) - $script:LastReconnectAt).TotalSeconds -lt $ReconnectCooldownSec) { return $false }

    $currentSignal = [int]$CurrentWifiState.Signal
    $targetSignal = 0
    $targetNetwork = Get-VisibleWifiNetworks | Where-Object { $_.SSID -eq $TargetSsid } | Select-Object -First 1
    if ($targetNetwork -and $null -ne $targetNetwork.Signal) { $targetSignal = [int]$targetNetwork.Signal }

    if ($targetSignal -ge ($currentSignal + 5)) { return $true }
    if ($targetSignal -ge 70 -and $currentSignal -lt 70) { return $true }
    return $false
}

function Restart-WifiConnection {
    $currentWifiState = Get-CurrentWifiState
    $targetSsid = Get-BestFreeNetwork -CurrentWifiState $currentWifiState
    if (-not $targetSsid) { $targetSsid = $script:LastKnownSSID }
    if (-not $targetSsid) { $targetSsid = $currentWifiState.SSID }
    Add-Log "Restart-WifiConnection: current='$($currentWifiState.SSID)' ($($currentWifiState.Signal)%), target='$targetSsid'"
    if ($targetSsid -and -not (Test-WifiSwitchNeeded -TargetSsid $targetSsid -CurrentWifiState $currentWifiState)) {
        Add-Log "Restart-WifiConnection: switch not needed/allowed right now (cooldown or same network), skipping."
        return $currentWifiState.SSID
    }

    Add-Log "Disconnecting current Wi-Fi connection..."
    netsh wlan disconnect 2>$null | Out-Null
    Start-Sleep -Seconds 2
    
    $candidates = Get-AllTrustedNetworksByScore -CurrentWifiState $currentWifiState
    if ($candidates -and $candidates.Count -gt 0) {
        $connected = $false
        foreach ($candidate in $candidates) {
            Add-Log "Attempting to connect to '$($candidate.SSID)' (score $($candidate.Score))..."
            if (Connect-ToWifiNetwork -Ssid $candidate.SSID) {
                Add-Log "Connected to '$($candidate.SSID)' successfully. Flushing DNS and resetting portal session."
                Clear-DnsCache
                $script:LastKnownSSID = $candidate.SSID
                $script:LastReconnectAt = Get-Date
                $script:PortalSession = $null
                $connected = $true
                break
            }
            Add-Log "Connect attempt to '$($candidate.SSID)' failed, trying next trusted network..."
        }
        
        if (-not $connected) {
            Add-Log "All trusted network connect attempts failed. Attempting DHCP release/renew before power-cycling adapter..."
            try {
                ipconfig /release | Out-Null
                Start-Sleep -Milliseconds 500
                ipconfig /renew | Out-Null
                Add-Log "DHCP release/renew completed. Retrying connection to best network..."
                $bestRetry = Get-BestFreeNetwork -CurrentWifiState $currentWifiState
                if ($bestRetry -and (Connect-ToWifiNetwork -Ssid $bestRetry)) {
                    Add-Log "Connected to '$bestRetry' successfully after DHCP renew. Flushing DNS and resetting portal session."
                    Clear-DnsCache
                    $script:LastKnownSSID = $bestRetry
                    $script:LastReconnectAt = Get-Date
                    $script:PortalSession = $null
                    $connected = $true
                }
            }
            catch {
                Add-Log "DHCP release/renew failed: $($_.Exception.Message)"
            }
            
            if (-not $connected) {
                Add-Log "DHCP renew did not restore connectivity. Falling back to power-cycling the adapter."
                $adapter = Get-WifiAdapter
                if ($adapter) {
                    Add-Log "Power-cycling adapter '$($adapter.Name)' ($($adapter.InterfaceDescription))..."
                    Disable-NetAdapter -Name $adapter.Name -Confirm:$false
                    Start-Sleep -Seconds 2
                    Enable-NetAdapter -Name $adapter.Name -Confirm:$false
                    Add-Log "Adapter '$($adapter.Name)' re-enabled."
                }
                else {
                    Add-Log "No Wi-Fi adapter found to power-cycle."
                }
            }
        }
    }
    else {
        Add-Log "No target SSID available at all (not even a last-known one). Power-cycling adapter as a last resort."
        $adapter = Get-WifiAdapter
        if ($adapter) {
            Add-Log "Power-cycling adapter '$($adapter.Name)' ($($adapter.InterfaceDescription))..."
            Disable-NetAdapter -Name $adapter.Name -Confirm:$false
            Start-Sleep -Seconds 2
            Enable-NetAdapter -Name $adapter.Name -Confirm:$false
            Add-Log "Adapter '$($adapter.Name)' re-enabled."
        }
        else {
            Add-Log "No Wi-Fi adapter found to power-cycle."
        }
    }
    Start-Sleep -Seconds 3
    return $targetSsid
}

function Test-PortalSession {
    foreach ($testPage in $TestPageUrls) {
        try {
            if ($script:PortalSession) {
                $resp = Invoke-WebRequest -Uri $testPage.Url -UseBasicParsing -TimeoutSec 6 -ErrorAction Stop -WebSession $script:PortalSession -Headers @{ 'Cache-Control' = 'no-cache'; Pragma = 'no-cache' }
            }
            else {
                $resp = Invoke-WebRequest -Uri $testPage.Url -UseBasicParsing -TimeoutSec 6 -ErrorAction Stop -SessionVariable 'newSession' -Headers @{ 'Cache-Control' = 'no-cache'; Pragma = 'no-cache' }
                $script:PortalSession = $newSession
            }
            $content = $resp.Content.Trim()
            if ($content -eq $testPage.ExpectedText) { return 'Active' }
            $preview = $content.Substring(0, [Math]::Min(120, $content.Length)) -replace '[\r\n]+', ' '
            Add-Log "Portal check returned unexpected content from $($testPage.Url) (first 120 chars): $preview"
            return 'LoggedOut'
        }
        catch {
            Add-Log "Portal connectivity check failed for $($testPage.Url): $($_.Exception.Message) - trying next endpoint..."
            continue
        }
    }
    Add-Log "All portal connectivity check endpoints failed."
    return 'Unknown'
}

function Invoke-PortalLogin {
    $cred = Get-PortalCredential
    $body = @{ dst = ""; popup = "true"; username = $cred.Username; password = $cred.Password }
    $loginUrls = @($LoginUrl, ($LoginUrl -replace '^https://', 'http://'))
    foreach ($url in $loginUrls) {
        try {
            if (-not $script:PortalSession) {
                $resp = Invoke-WebRequest -Uri $url -Method Post -Body $body -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop -SessionVariable 'newSession' -Headers @{ 'Cache-Control' = 'no-cache'; Pragma = 'no-cache' }
                $script:PortalSession = $newSession
            }
            else {
                $resp = Invoke-WebRequest -Uri $url -Method Post -Body $body -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop -WebSession $script:PortalSession -Headers @{ 'Cache-Control' = 'no-cache'; Pragma = 'no-cache' }
            }
            $content = $resp.Content
            if ($resp.BaseResponse.ResponseUri -match '/login' -or $content -match "Landmark University Hotspot Login" -or $content -match 'action="https://internet\.lmu\.edu\.ng/login"') {
                if ($url -eq $loginUrls[-1]) { throw "Portal login page returned after submitting credentials." }
                continue
            }
            if ($content -match 'already logged in|already login|logged in|connected') {
                return @{ Success = $true; AlreadyLoggedIn = $true; Url = $url }
            }
            return @{ Success = $true; AlreadyLoggedIn = $false; Url = $url }
        }
        catch {
            if ($url -like 'http://*') {
                Add-Log "WARNING: Portal login fell back to an unencrypted HTTP connection for this attempt."
            }
            if ($url -eq $loginUrls[-1]) { throw $_ }
        }
    }
}

function Invoke-PortalLogout {
    if (-not $script:PortalSession) { return $false }
    $logoutUrls = @($LogoutUrl, ($LogoutUrl -replace '^https://', 'http://'))
    foreach ($url in $logoutUrls) {
        try {
            Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 8 -ErrorAction Stop -WebSession $script:PortalSession -Headers @{ 'Cache-Control' = 'no-cache'; Pragma = 'no-cache' } | Out-Null
            $script:PortalSession = $null
            return $true
        }
        catch {
            if ($url -eq $logoutUrls[-1]) { return $false }
        }
    }
}

# ---------- WPF UI Setup ----------
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Xaml
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -Name Win32ForegroundHelper -Namespace NexLink -MemberDefinition '
[DllImport("user32.dll")]
public static extern bool AllowSetForegroundWindow(int dwProcessId);
'

# XAML for the main window
$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="NexLink" 
        Width="360" Height="520"
        WindowStyle="None"
        AllowsTransparency="True"
        Background="Transparent"
        ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen">
    <Border Name="MainBorder" Background="#0B0D13" CornerRadius="12" BorderBrush="#1F2937" BorderThickness="1">
        <Grid>
            <!-- Custom Title Bar -->
            <Grid Name="TitleBar" Height="40" VerticalAlignment="Top" Background="#14171F">
                <TextBlock Text="NexLink" FontFamily="Segoe UI" FontSize="14" FontWeight="SemiBold" 
                           Foreground="#F5F5F7" VerticalAlignment="Center" Margin="16,0,0,0"/>
                <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,0,8,0">
                    <Button Name="MinimizeBtn" Content="─" Width="30" Height="30" 
                            Background="Transparent" Foreground="#9CA3AF" 
                            BorderThickness="0" FontFamily="Segoe UI" FontSize="16"
                            Cursor="Hand"/>
                    <Button Name="CloseBtn" Content="✕" Width="30" Height="30" 
                            Background="Transparent" Foreground="#9CA3AF" 
                            BorderThickness="0" FontFamily="Segoe UI" FontSize="14"
                            Cursor="Hand"/>
                </StackPanel>
            </Grid>
            
            <!-- Status Orb with Pulse Animation -->
            <Ellipse Name="StatusOrb" Width="120" Height="120" 
                     Fill="#22D3AA" Stroke="#22D3AA" StrokeThickness="2"
                     VerticalAlignment="Top" Margin="0,60,0,0" HorizontalAlignment="Center">
                <Ellipse.Triggers>
                    <EventTrigger RoutedEvent="Ellipse.Loaded">
                        <BeginStoryboard>
                            <Storyboard RepeatBehavior="Forever" Name="PulseStoryboard">
                                <DoubleAnimation Storyboard.TargetProperty="(Ellipse.Opacity)"
                                               From="1.0" To="0.7" Duration="0:0:1.5"
                                               AutoReverse="True"/>
                            </Storyboard>
                        </BeginStoryboard>
                    </EventTrigger>
                </Ellipse.Triggers>
            </Ellipse>
            
            <!-- Status Text -->
            <TextBlock Name="StatusText" Text="Starting..." 
                       FontFamily="Segoe UI" FontSize="22" FontWeight="SemiBold"
                       Foreground="#F5F5F7" TextAlignment="Center"
                       VerticalAlignment="Top" Margin="0,200,0,0" HorizontalAlignment="Center"/>
            
            <!-- Network Name -->
            <TextBlock Name="NetworkName" Text="" 
                       FontFamily="Segoe UI" FontSize="12" FontWeight="Regular"
                       Foreground="#9CA3AF" TextAlignment="Center"
                       VerticalAlignment="Top" Margin="0,240,0,0" HorizontalAlignment="Center"/>
            
            <!-- Primary Action Button -->
            <Button Name="ActionButton" Content="Disconnect" 
                    Width="200" Height="44" 
                    FontFamily="Segoe UI" FontSize="14" FontWeight="SemiBold"
                    Foreground="#FFFFFF" 
                    VerticalAlignment="Top" Margin="0,300,0,0" HorizontalAlignment="Center"
                    Cursor="Hand">
                <Button.Template>
                    <ControlTemplate TargetType="Button">
                        <Border Name="ButtonBorder" Background="#7C3AED" CornerRadius="22" BorderThickness="0">
                            <Border.Background>
                                <LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
                                    <GradientStop Color="#7C3AED" Offset="0"/>
                                    <GradientStop Color="#06B6D4" Offset="1"/>
                                </LinearGradientBrush>
                            </Border.Background>
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                    </ControlTemplate>
                </Button.Template>
            </Button>
            
            <!-- Update banner - hidden unless an update is actually found -->
            <Border Name="UpdateBanner" Background="#14171F" CornerRadius="10"
                    VerticalAlignment="Bottom" Margin="16,0,16,44" Padding="10,8"
                    Visibility="Collapsed" BorderBrush="#06B6D4" BorderThickness="1">
                <Grid>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Name="UpdateBannerText" Grid.Column="0" Text="Update available"
                               FontFamily="Segoe UI" FontSize="11" Foreground="#F5F5F7"
                               VerticalAlignment="Center" TextWrapping="Wrap"/>
                    <Button Name="UpdateRestartBtn" Grid.Column="1" Content="Restart to Update"
                            FontFamily="Segoe UI" FontSize="10" FontWeight="SemiBold"
                            Background="#06B6D4" Foreground="White" BorderThickness="0"
                            Padding="8,4" Cursor="Hand" Margin="8,0,0,0"/>
                </Grid>
            </Border>

            <!-- Footer -->
            <Grid Height="30" VerticalAlignment="Bottom" Margin="16,0,16,8">
                <TextBlock Name="VersionText" Text="v1.3.0" 
                           FontFamily="Segoe UI" FontSize="10" 
                           Foreground="#6B7280" VerticalAlignment="Center" HorizontalAlignment="Left"/>
                <Button Name="SettingsBtn" Content="⚙" Width="24" Height="24" 
                        Background="Transparent" Foreground="#6B7280" 
                        BorderThickness="0" FontFamily="Segoe UI" FontSize="14"
                        Cursor="Hand" HorizontalAlignment="Right" VerticalAlignment="Center"/>
            </Grid>
        </Grid>
    </Border>
</Window>
"@

# Parse XAML
$stringReader = [System.IO.StringReader]::new($xaml)
$reader = [System.Xml.XmlReader]::Create($stringReader)
try {
    $window = [System.Windows.Markup.XamlReader]::Load($reader)
}
finally {
    $reader.Close()
    $stringReader.Dispose()
}

# Get UI elements
$statusOrb = $window.FindName("StatusOrb")
$statusText = $window.FindName("StatusText")
$networkName = $window.FindName("NetworkName")
$actionButton = $window.FindName("ActionButton")
$settingsBtn = $window.FindName("SettingsBtn")
$updateBanner = $window.FindName("UpdateBanner")
$updateBannerText = $window.FindName("UpdateBannerText")
$updateRestartBtn = $window.FindName("UpdateRestartBtn")
$versionText = $window.FindName("VersionText")
$versionText.Text = "v$NexLinkVersion"
$minimizeBtn = $window.FindName("MinimizeBtn")
$closeBtn = $window.FindName("CloseBtn")
$pulseStoryboard = $window.FindName("PulseStoryboard")

# Window dragging (manual implementation to avoid lag)
$script:isDragging = $false
$script:dragStartPoint = $null

$window.Add_MouseLeftButtonDown({
    $script:isDragging = $true
    $script:dragStartPoint = [System.Windows.Point]::new($_.GetPosition($this).X, $_.GetPosition($this).Y)
    $this.CaptureMouse()
})

$window.Add_MouseLeftButtonUp({
    $script:isDragging = $false
    $this.ReleaseMouseCapture()
})

$window.Add_MouseMove({
    if ($script:isDragging) {
        $currentPoint = $_.GetPosition($this)
        $deltaX = $currentPoint.X - $script:dragStartPoint.X
        $deltaY = $currentPoint.Y - $script:dragStartPoint.Y
        $this.Left += $deltaX
        $this.Top += $deltaY
    }
})

# Close button - behaves like minimize (sends to tray), matching standard
# background-app convention (Discord, Spotify, etc). Real exit only via the
# tray icon's right-click "Exit" menu item below.
$closeBtn.Add_Click({
    $window.WindowState = [System.Windows.WindowState]::Minimized
    $window.Hide()
    $trayIcon.ShowBalloonTip(2500, "NexLink", "Still running - look for this icon in your system tray (click the ^ arrow if you don't see it).", [System.Windows.Forms.ToolTipIcon]::Info)
})

# Minimize button
$minimizeBtn.Add_Click({
    $window.WindowState = [System.Windows.WindowState]::Minimized
    $window.Hide()
    $trayIcon.ShowBalloonTip(2500, "NexLink", "Still running - look for this icon in your system tray (click the ^ arrow if you don't see it).", [System.Windows.Forms.ToolTipIcon]::Info)
})

# ---------- Logging Functions ----------
$script:logLines = @()

function Add-Log($text) {
    $timestamp = Get-Date -Format 'HH:mm:ss'
    $line = "[$timestamp] $text"
    $script:logLines += $line
    try {
        $logDir = Split-Path -Parent $LogFile
        if ($logDir -and -not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
        Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
    }
    catch {}
}

function Limit-LogFile {
    try {
        if (-not (Test-Path $LogFile)) { return }
        $lines = Get-Content -Path $LogFile -ErrorAction SilentlyContinue
        if ($lines -and $lines.Count -gt ($MaxLogLines * 2)) {
            $trimmed = $lines[-$MaxLogLines..-1]
            Set-Content -Path $LogFile -Value $trimmed -Encoding UTF8
        }
        # Also trim in-memory array to prevent unbounded growth
        if ($script:logLines.Count -gt ($MaxLogLines * 2)) {
            $script:logLines = $script:logLines[-$MaxLogLines..-1]
        }
    }
    catch {}
}

# ---------- Pro License Functions ----------
# Embedded ECDSA public key for license verification (safe to expose)
# This is the public key corresponding to the private key in the Cloudflare Worker
# MANUAL ACTION REQUIRED: After generating ECDSA keys, replace the placeholder values below
# with the actual x and y coordinates from ecdsa_public_key.json
$script:ProPublicKey = @{
    curve = "P-256"
    x = "yg0VaTuX8pv8kJlfoFIOXFDdgW2vhipwb8sQjb1QlNw="
    y = "uYyJ9dNVOTu3HiTerRBEojxnGSend6kgMJgeb4W6rG8="
}

$script:ProLicenseFile = Join-Path $ScriptDir "nexlink_pro_license.cred"
$script:IsProLicensed = $false

function Get-MachineFingerprint {
    try {
        $guid = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid -ErrorAction Stop).MachineGuid
    }
    catch {
        # Registry key inaccessible for some reason - fall back to CIM, then hostname
        try {
            $guid = (Get-CimInstance -ClassName Win32_ComputerSystemProduct -ErrorAction Stop).UUID
        }
        catch {
            $guid = $env:COMPUTERNAME
        }
    }
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes([string]$guid)
    $hashBytes = $sha256.ComputeHash($bytes)
    $sha256.Dispose()
    return [Convert]::ToBase64String($hashBytes)
}

function Invoke-LicenseActivation($licenseKey) {
    $activateUrl = "https://nexlink-license.highnine699.workers.dev/activate"
    $machineHash = Get-MachineFingerprint
    $body = @{ licenseKey = $licenseKey; machineHash = $machineHash } | ConvertTo-Json -Compress

    try {
        Invoke-WebRequest -Uri $activateUrl -Method Post -Body $body -ContentType "application/json" -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop | Out-Null
        return @{ Success = $true; MachineHash = $machineHash }
    }
    catch {
        $statusCode = $null
        if ($_.Exception.Response) {
            try { $statusCode = [int]$_.Exception.Response.StatusCode } catch {}
        }
        if ($statusCode -eq 409) {
            Add-Log "License activation rejected: this key is already active on another device."
            return @{ Success = $false; Reason = "AlreadyActivated" }
        }
        Add-Log "License activation could not reach the server: $($_.Exception.Message)"
        return @{ Success = $false; Reason = "NetworkError" }
    }
}

function Get-ProLicense {
    try {
        if (-not (Test-Path $script:ProLicenseFile)) { return $null }
        $encrypted = (Get-Content -Path $script:ProLicenseFile -Raw -ErrorAction Stop).Trim()
        $secure = ConvertTo-SecureString $encrypted
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
        try {
            $payload = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        }
        finally {
            [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }
        return $payload | ConvertFrom-Json
    }
    catch {
        Add-Log "Pro license file could not be read/decrypted (may be from a different user/machine): $($_.Exception.Message)"
        return $null
    }
}

function Save-ProLicense($licenseKey, $machineHash) {
    try {
        $payload = @{ LicenseKey = $licenseKey; MachineHash = $machineHash } | ConvertTo-Json -Compress
        $secure = ConvertTo-SecureString $payload -AsPlainText -Force
        $encrypted = ConvertFrom-SecureString $secure
        Set-Content -Path $script:ProLicenseFile -Value $encrypted -Encoding UTF8 -Force -NoNewline
        return $true
    }
    catch {
        Add-Log "Failed to save Pro license: $($_.Exception.Message)"
        return $false
    }
}

function Verify-ProLicense($licenseKey) {
    if (-not $licenseKey -or $licenseKey.Trim() -eq "") { return $false }
    $parts = $licenseKey.Trim().Split(".")
    if ($parts.Count -ne 2) { return $false }

    try {
        $referenceBytes = [Convert]::FromBase64String($parts[0])
        $signatureBytes = [Convert]::FromBase64String($parts[1])
        $reference = [System.Text.Encoding]::UTF8.GetString($referenceBytes)

        $X = [Convert]::FromBase64String($script:ProPublicKey.x)
        $Y = [Convert]::FromBase64String($script:ProPublicKey.y)
        $magicBytes = [BitConverter]::GetBytes([UInt32]0x31534345)
        $keySizeBytes = [BitConverter]::GetBytes([UInt32]32)
        $blob = $magicBytes + $keySizeBytes + $X + $Y

        $cngKey = [System.Security.Cryptography.CngKey]::Import($blob, [System.Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
        $ecdsa = New-Object System.Security.Cryptography.ECDsaCng($cngKey)

        $messageBytes = [System.Text.Encoding]::UTF8.GetBytes($reference)
        $isValid = $ecdsa.VerifyData($messageBytes, $signatureBytes, [System.Security.Cryptography.HashAlgorithmName]::SHA256)
        $ecdsa.Dispose()
        $cngKey.Dispose()

        if ($isValid) {
            Add-Log "License verified for reference: $reference"
        }
        return $isValid
    }
    catch {
        Add-Log "License verification error: $($_.Exception.Message)"
        return $false
    }
}

function Show-LicenseInputDialog {
    $licenseKey = [Microsoft.VisualBasic.Interaction]::InputBox(
        "Enter your NexLink Pro license key:",
        "NexLink Pro License",
        "",
        -1, -1
    )

    if ($licenseKey -and $licenseKey.Trim() -ne "") {
        $licenseKey = $licenseKey.Trim()
        if (Verify-ProLicense $licenseKey) {
            $activation = Invoke-LicenseActivation $licenseKey
            if ($activation.Success) {
                if (Save-ProLicense $licenseKey $activation.MachineHash) {
                    $script:IsProLicensed = $true
                    Add-Log "Pro license activated successfully on this device."
                    [System.Windows.Forms.MessageBox]::Show("Pro license activated successfully!", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
                }
                else {
                    Add-Log "Failed to save Pro license locally."
                    [System.Windows.Forms.MessageBox]::Show("License verified but could not be saved locally. Try again.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
                }
            }
            elseif ($activation.Reason -eq "AlreadyActivated") {
                [System.Windows.Forms.MessageBox]::Show("This license key is already active on another device. Each purchase is valid for one device. If you believe this is an error, contact support.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
            }
            else {
                [System.Windows.Forms.MessageBox]::Show("Could not reach the activation server. Check your internet connection and try again.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            }
        }
        else {
            Add-Log "Invalid Pro license key provided."
            [System.Windows.Forms.MessageBox]::Show("Invalid license key. Please check and try again.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        }
    }
}

# Check for existing Pro license on startup
$savedLicense = Get-ProLicense
if ($savedLicense -and (Verify-ProLicense $savedLicense.LicenseKey)) {
    $currentMachineHash = Get-MachineFingerprint
    if ($savedLicense.MachineHash -eq $currentMachineHash) {
        $script:IsProLicensed = $true
        Add-Log "Pro license detected and valid for this device."
    }
    else {
        Add-Log "Pro license found but it's bound to a different device - Pro features disabled here."
    }
}

# Theme definitions
$script:Themes = @{
    "Cyberpunk" = @{
        Background = "#0B0D13"
        TitleBar = "#14171F"
        AccentStart = "#7C3AED"
        AccentEnd = "#06B6D4"
        StatusConnected = "#22D3AA"
        StatusReconnecting = "#FBBF24"
        StatusError = "#F43F5E"
        StatusOffline = "#6B7280"
    }
    "Sunset" = @{
        Background = "#1A1414"
        TitleBar = "#2D1F1F"
        AccentStart = "#F97316"
        AccentEnd = "#EC4899"
        StatusConnected = "#22D3AA"
        StatusReconnecting = "#FBBF24"
        StatusError = "#F43F5E"
        StatusOffline = "#6B7280"
    }
    "Midnight" = @{
        Background = "#0F172A"
        TitleBar = "#1E293B"
        AccentStart = "#3B82F6"
        AccentEnd = "#6366F1"
        StatusConnected = "#22D3AA"
        StatusReconnecting = "#FBBF24"
        StatusError = "#F43F5E"
        StatusOffline = "#6B7280"
    }
}

$script:CurrentTheme = "Cyberpunk"
$script:ThemeFile = Join-Path $ScriptDir "nexlink_theme.txt"

# Load saved theme preference
if (Test-Path $script:ThemeFile) {
    $savedTheme = Get-Content $script:ThemeFile -ErrorAction SilentlyContinue
    if ($script:Themes.ContainsKey($savedTheme)) {
        $script:CurrentTheme = $savedTheme
    }
}

function Show-ThemePickerDialog {
    $themeForm = New-Object System.Windows.Forms.Form
    $themeForm.Text = "Choose Theme"
    $themeForm.Width = 300
    $themeForm.Height = 200
    $themeForm.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $themeForm.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $themeForm.MaximizeBox = $false
    $themeForm.MinimizeBox = $false

    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Select a theme:"
    $label.Location = New-Object System.Drawing.Point(20, 20)
    $label.AutoSize = $true
    $themeForm.Controls.Add($label)

    $combo = New-Object System.Windows.Forms.ComboBox
    $combo.Location = New-Object System.Drawing.Point(20, 50)
    $combo.Width = 240
    $combo.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
    foreach ($themeName in $script:Themes.Keys) {
        $combo.Items.Add($themeName) | Out-Null
    }
    $combo.SelectedIndex = [Array]::IndexOf($script:Themes.Keys, $script:CurrentTheme)
    $themeForm.Controls.Add($combo)

    $okBtn = New-Object System.Windows.Forms.Button
    $okBtn.Text = "Apply"
    $okBtn.Location = New-Object System.Drawing.Point(20, 90)
    $okBtn.Width = 100
    $okBtn.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $themeForm.Controls.Add($okBtn)

    $cancelBtn = New-Object System.Windows.Forms.Button
    $cancelBtn.Text = "Cancel"
    $cancelBtn.Location = New-Object System.Drawing.Point(140, 90)
    $cancelBtn.Width = 100
    $cancelBtn.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $themeForm.Controls.Add($cancelBtn)

    $result = $themeForm.ShowDialog()
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        $selectedTheme = $combo.SelectedItem
        Apply-Theme $selectedTheme
        $script:CurrentTheme = $selectedTheme
        $selectedTheme | Out-File $script:ThemeFile -Encoding UTF8
        Add-Log "Theme changed to: $selectedTheme"
    }

    $themeForm.Dispose()
}

function Apply-Theme($themeName) {
    $theme = $script:Themes[$themeName]
    if (-not $theme) { return }

    # Update main window background
    $mainBorder = $window.FindName("MainBorder")
    if ($mainBorder) {
        $mainBorder.Background = $theme.Background
    }

    # Update title bar background
    $titleBar = $window.FindName("TitleBar")
    if ($titleBar) {
        $titleBar.Background = $theme.TitleBar
    }

    # Update action button gradient by recreating the template
    $actionButton = $window.FindName("ActionButton")
    if ($actionButton) {
        $newTemplate = @'
<ControlTemplate TargetType="Button" xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation">
    <Border Name="ButtonBorder" CornerRadius="22" BorderThickness="0">
        <Border.Background>
            <LinearGradientBrush StartPoint="0,0" EndPoint="1,0">
                <GradientStop Color="ACCENT_START" Offset="0"/>
                <GradientStop Color="ACCENT_END" Offset="1"/>
            </LinearGradientBrush>
        </Border.Background>
        <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
    </Border>
</ControlTemplate>
'@
        $newTemplate = $newTemplate -replace "ACCENT_START", $theme.AccentStart
        $newTemplate = $newTemplate -replace "ACCENT_END", $theme.AccentEnd
        
        $reader = [System.Xml.XmlReader]::Create([System.IO.StringReader]::new($newTemplate))
        $actionButton.Template = [System.Windows.Markup.XamlReader]::Load($reader)
    }

    # Update update banner
    $updateBanner = $window.FindName("UpdateBanner")
    if ($updateBanner) {
        $updateBanner.Background = $theme.TitleBar
    }

    # Trigger status update to refresh orb colors with new theme
    $statusText = $window.FindName("StatusText")
    if ($statusText) {
        Set-Status $statusText.Text "default"
    }
}

# ---------- Status Update Function ----------
function Set-Status($text, $state) {
    $statusText.Text = $text
    $trayIcon.Text = "NexLink: $text"
    
    # Get current theme colors
    $theme = $script:Themes[$script:CurrentTheme]
    if (-not $theme) { $theme = $script:Themes["Cyberpunk"] }
    
    # Update orb color and animation based on state using theme colors
    switch ($state) {
        "Connected" {
            $statusOrb.Fill = $theme.StatusConnected
            $statusOrb.Stroke = $theme.StatusConnected
            if ($pulseStoryboard) { try { $pulseStoryboard.Begin() } catch {} }
        }
        "Reconnecting" {
            $statusOrb.Fill = $theme.StatusReconnecting
            $statusOrb.Stroke = $theme.StatusReconnecting
            if ($pulseStoryboard) { try { $pulseStoryboard.Begin() } catch {} }
        }
        "Error" {
            $statusOrb.Fill = $theme.StatusError
            $statusOrb.Stroke = $theme.StatusError
            if ($pulseStoryboard) { try { $pulseStoryboard.Stop() } catch {} }
        }
        default {
            $statusOrb.Fill = $theme.StatusOffline
            $statusOrb.Stroke = $theme.StatusOffline
            if ($pulseStoryboard) { try { $pulseStoryboard.Stop() } catch {} }
        }
    }
}

# ---------- Manual Disconnect/Reconnect ----------
$script:ManuallyDisconnected = $false

function Disconnect-Manually {
    $timer.Stop()
    Set-Status "Logging out..." "Reconnecting"
    $loggedOut = Invoke-PortalLogout
    if ($loggedOut) {
        Add-Log "Portal session logged out."
    }
    else {
        Add-Log "Portal logout could not be confirmed (already logged out, or no active session)."
    }
    netsh wlan disconnect 2>$null | Out-Null
    $script:ManuallyDisconnected = $true
    $actionButton.Content = "Reconnect Now"
    Set-Status "Disconnected" "Error"
    Add-Log "Manually disconnected. Auto-reconnect is paused until you click Reconnect."
}

function Reconnect-Manually {
    $script:ManuallyDisconnected = $false
    $actionButton.Content = "Disconnect"
    Add-Log "Manual reconnect requested."
    Set-Status "Reconnecting..." "Reconnecting"
    Restart-WifiConnection | Out-Null
    $script:wifiFailCount = 0
    $script:portalFailCount = 0
    $script:secondsToNextCheck = $CheckIntervalMs / 1000
    $timer.Interval = $CheckIntervalMs
    $timer.Start()
}

$actionButton.Add_Click({
    if ($script:ManuallyDisconnected) {
        Reconnect-Manually
    }
    else {
        Disconnect-Manually
    }
})

# ---------- System Tray (Hybrid: WPF + WinForms) ----------
$trayIcon = New-Object System.Windows.Forms.NotifyIcon
$iconPath = Join-Path $ScriptDir "wifi_icon.ico"
if (Test-Path $iconPath) {
    $trayIcon.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($iconPath)
} else {
    $trayIcon.Icon = [System.Drawing.SystemIcons]::Application
}
$trayIcon.Text = "NexLink v$NexLinkVersion Monitor"
$trayIcon.Visible = $true

$trayMenu = New-Object System.Windows.Forms.ContextMenuStrip
$menuShow = $trayMenu.Items.Add("Show Window")
$menuDisconnect = $trayMenu.Items.Add("Disconnect")
$trayMenu.Items.Add("-") | Out-Null
$menuExit = $trayMenu.Items.Add("Exit")
$trayIcon.ContextMenuStrip = $trayMenu

$script:allowExit = $false

$menuShow.Add_Click({ 
    $window.Show(); 
    $window.WindowState = "Normal"; 
    $window.Activate() 
})
$trayIcon.Add_DoubleClick({ 
    $window.Show(); 
    $window.WindowState = "Normal"; 
    $window.Activate() 
})

$trayMenu.Add_Opening({
    $menuDisconnect.Text = if ($script:ManuallyDisconnected) { "Reconnect" } else { "Disconnect" }
})

$menuDisconnect.Add_Click({
    if ($script:ManuallyDisconnected) {
        Reconnect-Manually
    }
    else {
        Disconnect-Manually
    }
})

function Invoke-GracefulExit {
    $script:allowExit = $true
    $timer.Stop()
    $trayIcon.Visible = $false
    try { Unregister-Event -SourceIdentifier $powerModeChangedHandler.Name -ErrorAction SilentlyContinue } catch {}
    try { [System.Net.NetworkInformation.NetworkChange]::remove_NetworkAddressChanged($script:NetworkAddressChangedHandler) } catch {}
    try { $script:InstanceMutex.ReleaseMutex() } catch {}
    Remove-Item $script:ExitSignalFile -ErrorAction SilentlyContinue
    $window.Close()
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
}

$menuExit.Add_Click({ Invoke-GracefulExit })

# ---------- Timer-driven check loop ----------
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds($CheckIntervalMs)

# Debounce state for NetworkAddressChanged (prevents duplicate checks during a single roam event)
$script:LastNetworkChangeCheckAt = [DateTime]::MinValue
$script:NetworkChangeDebounceSec = 2

# Shared immediate-check function used by both PowerModeChanged and NetworkAddressChanged handlers.
# Marshals back onto the WPF Dispatcher thread and sets a 1ms timer interval so the tick fires
# on the very next dispatcher frame instead of waiting up to $CheckIntervalMs.
function Invoke-ImmediateConnectivityCheck {
    Add-Log "Immediate connectivity check triggered (network or power event)."
    $window.Dispatcher.BeginInvoke([Action]{
        $timer.Stop()
        $timer.Interval = [TimeSpan]::FromMilliseconds(1)
        $timer.Start()
    })
}

# Power mode change event handler — fires an immediate check on wake from sleep.
$powerModeChangedHandler = Register-ObjectEvent -InputObject ([Microsoft.Win32.SystemEvents]) -EventName "PowerModeChanged" -Action {
    if ($EventArgs.Mode -eq [Microsoft.Win32.PowerModes]::Resume) {
        Add-Log "System resumed from sleep."
        Invoke-ImmediateConnectivityCheck
    }
}

# Network address change handler — fires an immediate check when the SSID, IP address,
# or adapter state changes (e.g. roaming between APs while walking between buildings).
# The debounce prevents the same physical roam event from triggering the check 2-3 times
# in rapid succession (IP release → IP acquire → adapter settle all fire this event).
$script:NetworkAddressChangedHandler = {
    if (((Get-Date) - $script:LastNetworkChangeCheckAt).TotalSeconds -lt $script:NetworkChangeDebounceSec) {
        return
    }
    $script:LastNetworkChangeCheckAt = Get-Date
    Add-Log "Network address change detected (SSID/IP/adapter change)."
    Invoke-ImmediateConnectivityCheck
}
[System.Net.NetworkInformation.NetworkChange]::add_NetworkAddressChanged($script:NetworkAddressChangedHandler)

$timer.Add_Tick({
    if (Test-Path $script:ExitSignalFile) {
        Invoke-GracefulExit
        return
    }
    if ($script:ManuallyDisconnected) { return }
    $script:secondsToNextCheck = $CheckIntervalMs / 1000
    if (((Get-Date) - $script:LastLogTrimAt).TotalHours -ge 1) {
        Limit-LogFile
        $script:LastLogTrimAt = Get-Date
    }
    if (-not $script:PendingUpdateManifest -and ((Get-Date) - $script:LastUpdateCheckAt).TotalHours -ge 24) {
        $script:LastUpdateCheckAt = Get-Date
        $foundUpdate = Test-ForUpdate
        if ($foundUpdate) {
            $script:PendingUpdateManifest = $foundUpdate
            $updateBannerText.Text = "v$($foundUpdate.version) is available"
            $updateBanner.Visibility = [System.Windows.Visibility]::Visible
        }
    }
    try {
        $currentWifiState = Get-CurrentWifiState
        $targetSsid = Get-BestFreeNetwork -CurrentWifiState $currentWifiState
        if (Test-WifiSwitchNeeded -TargetSsid $targetSsid -CurrentWifiState $currentWifiState) {
            Add-Log "Better Wi-Fi available ('$targetSsid'). Switching now."
            Set-Status "Switching Wi-Fi..." "Reconnecting"
            Restart-WifiConnection | Out-Null
            $script:wifiFailCount = 0
            $script:portalFailCount = 0
            $currentWifiState = Get-CurrentWifiState
        }

        $pingOk = $false
        foreach ($target in $PingTargets) {
            if (Test-Connection -ComputerName $target -Count 1 -Quiet -ErrorAction SilentlyContinue) {
                $pingOk = $true
                break
            }
        }

        if ($pingOk) {
            if ($script:wifiFailCount -gt 0) {
                Add-Log "Ping recovered after $script:wifiFailCount failure(s)."
            }
            $script:wifiFailCount = 0
            Update-KnownSSID | Out-Null
        }
        else {
            $script:wifiFailCount++
            Add-Log "Ping failed ($script:wifiFailCount/$WifiFailsBeforeFix) - targets=$($PingTargets -join ', ')"
            Set-Status "Fixing your connection..." "Reconnecting"
        }

        $portalStatus = Test-PortalSession
        Add-Log "[Check] Ping=$(if ($pingOk) {'OK'} else {'FAIL'}) Portal=$portalStatus SSID='$($currentWifiState.SSID)' Signal=$($currentWifiState.Signal)% Interval=$($timer.Interval.TotalMilliseconds)ms"
        
        if ($portalStatus -eq 'LoggedOut') {
            $now = Get-Date
            if ($script:PortalRetryAfter -gt $now) {
                if (-not $script:PortalCooldownShown) {
                    $remaining = [Math]::Ceiling(($script:PortalRetryAfter - $now).TotalSeconds)
                    Add-Log "Portal still appears logged out. Waiting $remaining seconds before retrying"
                    $script:PortalCooldownShown = $true
                }
            }
            else {
                $script:PortalCooldownShown = $false
                Set-Status "Logging into portal..." "Reconnecting"
                Add-Log "Portal session inactive - logging back in"
                try {
                    $result = Invoke-PortalLogin
                    Clear-DnsCache
                    Add-Log "Portal login submitted via '$($result.Url)' (AlreadyLoggedIn=$($result.AlreadyLoggedIn))"
                    $script:portalFailCount = 0
                    $script:wifiFailCount = 0
                    $script:portalUnknownCount = 0
                    $script:PortalRetryAfter = [DateTime]::MinValue
                }
                catch {
                    $script:portalFailCount++
                    $cooldownSeconds = [Math]::Min($PortalLoginRetryCooldownSec, 10 + ($script:portalFailCount * 5))
                    $script:PortalRetryAfter = $now.AddSeconds($cooldownSeconds)
                    Add-Log "Portal login FAILED ($script:portalFailCount). Retrying in $cooldownSeconds seconds: $($_.Exception.Message)"
                    Set-Status "Portal login error" "Error"
                }
            }
        }
        elseif ($portalStatus -eq 'Active') {
            $script:wifiFailCount = 0
            $script:portalFailCount = 0
            $script:portalUnknownCount = 0
            $script:PortalRetryAfter = [DateTime]::MinValue
            $script:PortalCooldownShown = $false
        }
        else {
            # 'Unknown' - can't even reach the connectivity-check endpoint.
            # Ping alone succeeding doesn't mean much if this keeps failing;
            # some networks allow ICMP but throttle/block specific HTTP
            # endpoints. Escalate after repeated Unknowns instead of waiting
            # forever with no action.
            $script:portalUnknownCount++
            Add-Log "Portal status Unknown ($script:portalUnknownCount/$WifiFailsBeforeFix) - can't reach connectivity-check endpoint"
            $script:PortalRetryAfter = [DateTime]::MinValue
            $script:PortalCooldownShown = $false
        }

        if ($script:wifiFailCount -ge $WifiFailsBeforeFix -or $script:portalFailCount -ge $WifiFailsBeforeFix -or $script:portalUnknownCount -ge $WifiFailsBeforeFix) {
            Set-Status "Reconnecting..." "Reconnecting"
            $ssid = Restart-WifiConnection
            Add-Log "Wi-Fi reconnect attempted (SSID: $ssid)"
            $script:wifiFailCount = 0
            $script:portalFailCount = 0
            $script:portalUnknownCount = 0
        }
        elseif ($portalStatus -eq 'Active') {
            Set-Status "You're connected" "Connected"
            $networkName.Text = $currentWifiState.SSID
            $now2 = Get-Date
            if ($script:LastLoggedStatus -ne 'Active') {
                Add-Log "Connected & Logged In (SSID: $($currentWifiState.SSID))"
                $script:LastLoggedStatus = 'Active'
                $script:LastHealthyLogAt = $now2
            }
            elseif (($now2 - $script:LastHealthyLogAt).TotalMinutes -ge 10) {
                Add-Log "Still connected & logged in (heartbeat, SSID: $($currentWifiState.SSID))"
                $script:LastHealthyLogAt = $now2
            }
        }
        else {
            $script:LastLoggedStatus = ""
        }

        $timer.Interval = [TimeSpan]::FromMilliseconds($CheckIntervalMs)
        $script:secondsToNextCheck = $timer.Interval.TotalMilliseconds / 1000
    }
    catch {
        Add-Log "ERROR: $($_.Exception.Message)"
        Set-Status "Error - see log" "Error"
    }
})

# ---------- Window Entrance Animation ----------
$window.Add_Loaded({
    # Fade-in animation
    $fadeIn = [System.Windows.Media.Animation.DoubleAnimation]::new(0, 1, [TimeSpan]::FromSeconds(0.25))
    $window.BeginAnimation([System.Windows.Window]::OpacityProperty, $fadeIn)

    Limit-LogFile
    $osInfo = try { (Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).Caption } catch { "unknown OS" }
    $adapterInfo = Get-WifiAdapter
    $adapterDesc = if ($adapterInfo) { "$($adapterInfo.Name) - $($adapterInfo.InterfaceDescription)" } else { "NOT FOUND" }
    Add-Log "===== Monitor started. Checking every $($CheckIntervalMs / 1000)s. ====="
    Add-Log "Version=$NexLinkVersion OS='$osInfo' Adapter='$adapterDesc'"
    Get-PortalCredential | Out-Null
    Update-KnownSSID | Out-Null
    $currentWifiState = Get-CurrentWifiState
    Add-Log "Startup Wi-Fi state: SSID='$($currentWifiState.SSID)' Signal=$($currentWifiState.Signal)%"
    $bestSsid = Get-BestFreeNetwork -CurrentWifiState $currentWifiState
    $currentSsid = $currentWifiState.SSID
    if ($bestSsid -and $currentSsid -and $currentSsid -ne $bestSsid) {
        Add-Log "Starting on '$currentSsid'; switching to preferred network '$bestSsid'"
        Restart-WifiConnection | Out-Null
    }
    $trayIcon.ShowBalloonTip(4000, "NexLink is running", "Look for this icon in your system tray. If you don't see it, click the small ^ arrow next to your other tray icons.", [System.Windows.Forms.ToolTipIcon]::Info)
    $timer.Start()

    # Update check runs last, after the core monitor is already active.
    # A slow or failed network check here can never delay or block the
    # app's actual job of keeping you connected.
    $script:LastUpdateCheckAt = Get-Date
    $foundUpdate = Test-ForUpdate
    if ($foundUpdate) {
        $script:PendingUpdateManifest = $foundUpdate
        $updateBannerText.Text = "v$($foundUpdate.version) is available"
        $updateBanner.Visibility = [System.Windows.Visibility]::Visible
    }
})

# ---------- Advanced Panel ----------
$advancedXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="NexLink Advanced" 
        Width="500" Height="400"
        WindowStyle="None"
        AllowsTransparency="True"
        Background="Transparent"
        ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen">
    <Border Background="#14171F" CornerRadius="8" BorderBrush="#1F2937" BorderThickness="1">
        <Grid>
            <!-- Title Bar -->
            <Grid Height="35" VerticalAlignment="Top" Background="#1F2937">
                <TextBlock Text="Advanced" FontFamily="Segoe UI" FontSize="12" FontWeight="SemiBold" 
                           Foreground="#F5F5F7" VerticalAlignment="Center" Margin="12,0,0,0"/>
                <Button Name="AdvCloseBtn" Content="✕" Width="30" Height="30" 
                        Background="Transparent" Foreground="#9CA3AF" 
                        BorderThickness="0" FontFamily="Segoe UI" FontSize="12"
                        Cursor="Hand" HorizontalAlignment="Right" Margin="0,0,8,0"/>
            </Grid>
            
            <!-- Log Viewer -->
            <TextBox Name="LogViewer" 
                     Background="#0B0D13" Foreground="#22D3AA" 
                     BorderBrush="#1F2937" BorderThickness="1"
                     FontFamily="Consolas" FontSize="10"
                     VerticalAlignment="Top" Margin="12,45,12,0" Height="220"
                     TextWrapping="Wrap" IsReadOnly="True" VerticalScrollBarVisibility="Auto"/>
            
            <!-- Buttons -->
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" 
                        VerticalAlignment="Bottom" Margin="0,0,0,12">
                <Button Name="ReenterCredBtn" Content="Re-enter Credentials" Width="140" Height="32"
                        Background="#374151" Foreground="#F5F5F7" BorderThickness="0"
                        FontFamily="Segoe UI" FontSize="11" Margin="0,0,8,0" Cursor="Hand"/>
                <Button Name="UpgradeBtn" Content="Upgrade to Pro" Width="120" Height="32"
                        Background="#10B981" Foreground="#F5F5F7" BorderThickness="0"
                        FontFamily="Segoe UI" FontSize="11" Margin="0,0,8,0" Cursor="Hand"/>
                <Button Name="EnterLicenseBtn" Content="Enter Pro License" Width="130" Height="32"
                        Background="#7C3AED" Foreground="#F5F5F7" BorderThickness="0"
                        FontFamily="Segoe UI" FontSize="11" Margin="0,0,8,0" Cursor="Hand"/>
                <Button Name="DeactivateLicenseBtn" Content="Deactivate License" Width="130" Height="32"
                        Background="#EF4444" Foreground="#F5F5F7" BorderThickness="0"
                        FontFamily="Segoe UI" FontSize="11" Margin="0,0,8,0" Cursor="Hand"/>
                <Button Name="ThemePickerBtn" Content="Change Theme" Width="110" Height="32"
                        Background="#374151" Foreground="#F5F5F7" BorderThickness="0"
                        FontFamily="Segoe UI" FontSize="11" Margin="0,0,8,0" Cursor="Hand"/>
                <Button Name="OpenLogBtn" Content="Open Log File" Width="120" Height="32"
                        Background="#374151" Foreground="#F5F5F7" BorderThickness="0"
                        FontFamily="Segoe UI" FontSize="11" Cursor="Hand"/>
            </StackPanel>
            
            <!-- Version -->
            <TextBlock Name="AdvVersionText" Text="v1.3.0" 
                       FontFamily="Segoe UI" FontSize="9" 
                       Foreground="#6B7280" VerticalAlignment="Bottom" HorizontalAlignment="Left" Margin="12,0,0,8"/>
        </Grid>
    </Border>
</Window>
"@

$advStringReader = [System.IO.StringReader]::new($advancedXaml)
$advReader = [System.Xml.XmlReader]::Create($advStringReader)
try {
    $advWindow = [System.Windows.Markup.XamlReader]::Load($advReader)
}
finally {
    $advReader.Close()
    $advStringReader.Dispose()
}

$advLogViewer = $advWindow.FindName("LogViewer")
$advCloseBtn = $advWindow.FindName("AdvCloseBtn")
$reenterCredBtn = $advWindow.FindName("ReenterCredBtn")
$upgradeBtn = $advWindow.FindName("UpgradeBtn")
$enterLicenseBtn = $advWindow.FindName("EnterLicenseBtn")
$deactivateLicenseBtn = $advWindow.FindName("DeactivateLicenseBtn")
$themePickerBtn = $advWindow.FindName("ThemePickerBtn")
$openLogBtn = $advWindow.FindName("OpenLogBtn")
$advVersionText = $advWindow.FindName("AdvVersionText")
$advVersionText.Text = "v$NexLinkVersion"

# Advanced window dragging
$advWindow.Add_MouseLeftButtonDown({
    $this.DragMove()
})

# Close advanced panel
$advCloseBtn.Add_Click({
    $advWindow.Hide()
})

# Re-enter credentials
$reenterCredBtn.Add_Click({
    if (Save-PortalCredential) {
        $script:PortalSession = $null
        Add-Log "Credentials re-entered by user."
        [System.Windows.Forms.MessageBox]::Show("Credentials updated successfully.", "NexLink") | Out-Null
    }
    else {
        Add-Log "Credential re-entry cancelled by user - existing credentials unchanged, app continues running."
    }
})

# Upgrade to Pro
$upgradeBtn.Add_Click({
    $paymentUrl = "https://paystack.shop/pay/nexlink-license"
    [System.Windows.Forms.MessageBox]::Show("This will open the Paystack payment page in your browser. Complete the payment to receive your Pro license key.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    Start-Process $paymentUrl
})

# Enter Pro License
$enterLicenseBtn.Add_Click({
    Show-LicenseInputDialog
})

# Theme picker (Pro feature)
$themePickerBtn.Add_Click({
    if (-not $script:IsProLicensed) {
        [System.Windows.Forms.MessageBox]::Show("Theme customization is a Pro feature. Please activate your license first.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        return
    }
    Show-ThemePickerDialog
})

# Deactivate License
$deactivateLicenseBtn.Add_Click({
    if (-not $script:IsProLicensed) {
        [System.Windows.Forms.MessageBox]::Show("No active Pro license to deactivate.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        return
    }
    
    $result = [System.Windows.Forms.MessageBox]::Show("Are you sure you want to deactivate your Pro license? This will remove all Pro features.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning)
    
    if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
        try {
            Remove-Item $script:ProLicenseFile -ErrorAction Stop
            $script:IsProLicensed = $false
            Add-Log "Pro license deactivated by user."
            [System.Windows.Forms.MessageBox]::Show("Pro license deactivated successfully.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        }
        catch {
            Add-Log "Failed to deactivate Pro license: $($_.Exception.Message)"
            [System.Windows.Forms.MessageBox]::Show("Failed to deactivate license. Please check logs for details.", "NexLink Pro", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        }
    }
})

# Open log file
$openLogBtn.Add_Click({
    if (Test-Path $LogFile) {
        [NexLink.Win32ForegroundHelper]::AllowSetForegroundWindow(-1) | Out-Null
        Start-Process notepad.exe $LogFile
    }
    else {
        [System.Windows.Forms.MessageBox]::Show("Log file not found.", "NexLink") | Out-Null
    }
})

# Update log viewer when advanced panel opens
$updateRestartBtn.Add_Click({
    if ($script:PendingUpdateManifest) {
        $updateRestartBtn.IsEnabled = $false
        $updateRestartBtn.Content = "Updating..."
        Start-NexLinkUpdate $script:PendingUpdateManifest
        # If we reach this line, the update did NOT proceed (download or
        # verification failed) - Start-NexLinkUpdate already logged why and
        # showed the user a message. Re-enable the button so they can retry.
        $updateRestartBtn.IsEnabled = $true
        $updateRestartBtn.Content = "Restart to Update"
    }
})

$settingsBtn.Add_Click({
    $advLogViewer.Text = $script:logLines -join "`r`n"
    $advLogViewer.ScrollToEnd()
    $advWindow.Show() | Out-Null
})

# ---------- Show Window ----------
$window.Add_Closed({
    # Safety net: if the window closes through any path we haven't
    # explicitly handled (Alt+F4, system menu, etc.), still clean up
    # properly instead of leaving a zombie process or orphaned tray icon.
    $timer.Stop()
    $trayIcon.Visible = $false
    try { Unregister-Event -SourceIdentifier $powerModeChangedHandler.Name -ErrorAction SilentlyContinue } catch {}
    try { [System.Net.NetworkInformation.NetworkChange]::remove_NetworkAddressChanged($script:NetworkAddressChangedHandler) } catch {}
    try { $script:InstanceMutex.ReleaseMutex() } catch {}
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
})
$window.Show()
[System.Windows.Threading.Dispatcher]::Run()
